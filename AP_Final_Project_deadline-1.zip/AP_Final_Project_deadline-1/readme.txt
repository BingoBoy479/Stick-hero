The submission at this stage (deadline - 1) has The UML class diagram, Use Case Diagram and 
A copy of the complete project files.

Please open the project and run the main method in HelloApplication class to run the application 
Which showcases the basic UI with some working buttons and scene switching.

The FXML files from which the UI was generated is also in the project files.

Please note that he game over button in game play screen is just to move to the game over screen as the game has 
No current logic as of now and acts as a basic skeleton only.

The starter code (methods and instance variables) has also been declared in the code without any body as comments 
So that there is no interference in the current code.

Link to Github Repository : https://github.com/pluto-tofu/AP_Final_Project_deadline-1.git

Paarth Goyal (2022343)
Shivankar Srijan Singh (2022343)
Group Number - 27 

