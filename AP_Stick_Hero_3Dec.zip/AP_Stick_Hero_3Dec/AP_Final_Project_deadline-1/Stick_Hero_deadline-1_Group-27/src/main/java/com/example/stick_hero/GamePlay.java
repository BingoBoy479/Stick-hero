package com.example.stick_hero;
import javafx.animation.*;
import java.util.Random;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;
import java.io.IOException;
import java.util.Objects;

public class GamePlay  {

    private Stage Game_Stage;
    private Scene Game_Scene;
    private int stick_has = 1;
    private int stick_rotate = 0;
    @FXML
    private ImageView s_hero;
    //private Parent root;
    // private Character character;
    // private Rectangle pillar_current;
    // private Rectangle pillar_next;
    // private Rectangle pillar_next_to_next;
    // private Imgview cherry;
    // private Rectangle stick;
    // private int score;
    //
    @FXML
    private Rectangle stick;
    @FXML
    private Rectangle starting_platform;
    @FXML
    private Rectangle next_platform;
    @FXML
    AnchorPane main_stuff;
    public int character_fate;
    public boolean cherry_is_there=false;
    public ImageView coin;
    public int Stick_checker(){
        double p = starting_platform.getLayoutX()+starting_platform.getWidth();
        double separation=(next_platform.getLayoutX()-p);
        System.out.println(separation);
        double difference=stick.getHeight()-separation;
        if(difference<0){
            //stick too short case
            System.out.println("OYE PAPAJI! OYE PAPAJI!");
            return -1;
        }

            else if(difference>next_platform.getWidth()){
                //stick too long case
                System.out.println("PAIN MAKES ME NUMB");
                return 0;
            }else{
                //stick just right
                System.out.println("JAI GANESH!");
                return 1;
            }


    }
    public double create_pillar(){
         //random numbers for variable pillar position and width
        Random rand = new Random();
        double rand_dub1 = rand.nextDouble(115,435);
        double max_allowed_width=569-rand_dub1;
        double rand_dub2 = rand.nextDouble(45,max_allowed_width);
        System.out.println("Random Doubles: "+rand_dub1);
        System.out.println("Random Doubles: "+rand_dub2);
        next_platform.setLayoutX(rand_dub1);
        next_platform.setWidth(rand_dub2);
        return rand_dub1;
    }
    public double position_of_cherry(double r){
        double a=0;
        Random ra =new Random();
        a=ra.nextDouble(starting_platform.getLayoutX()+starting_platform.getWidth(),r-25);
        return a;
    }
    public int chanceofcherry(){
        int a=0;
        Random raa=new Random();
        a=raa.nextInt(0,7);
        return a;
    }
    public void create_cherry(double a){
        //cherry ka luck wala feature added here
        coin = new ImageView();
        coin.setFitHeight(30);
        coin.setFitWidth(25);
        coin.setImage(new Image(getClass().getResourceAsStream("coin.png")));
        double position_of_next=a;
        int luck=chanceofcherry();
        System.out.println(luck);
        if(luck==0){
            double hello=position_of_cherry(position_of_next);
            main_stuff.getChildren().add(coin);
            coin.setX(hello);
            coin.setY(215);
            cherry_is_there=true;
            System.out.println(hello);
        }
    }

    
    public void initialize(){
        //stick generator
        Timeline stick_generate = new Timeline(new KeyFrame(Duration.seconds(0.01), event -> {
            stick.setHeight(stick.getHeight() + 1);
            stick.setY(stick.getY() - 1);
        }));
        stick_generate.setCycleCount(Timeline.INDEFINITE);

        //stick rotation timeline
        Rotate rotation = new Rotate();
        rotation.pivotXProperty().bind(stick.xProperty());
        rotation.pivotYProperty().bind(stick.yProperty().add(stick.heightProperty()));
        stick.getTransforms().add(rotation);
        Timeline stick_rotation = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(rotation.angleProperty(), 0)),
                new KeyFrame(Duration.seconds(0.5), new KeyValue(rotation.angleProperty(), 90))
        );
        
        double set=create_pillar();
        create_cherry(set);
        
        //Don't make multiple setOnKeyPressed as the code will call the last event handler
        //this is our keyboard input to code execution block

        main_stuff.setOnKeyPressed( event1 -> {
            switch(event1.getCode()) {
                case CONTROL:
                    System.out.println("hari om "+ event1.getCode());
                    switch(stick_has) {
                        case 0:
                            System.out.println("Stick already made");
                            break;
                        case 1:
                            stick_generate.play();
                            stick_has=0;
                            break;
                    }
                    break;
                case SHIFT:
                    //I have added this as a case of example : agar tujhe aur koi key press add karna ho toh just add a case here
                    //Aur yeh optimised hai: he he :)
                    System.out.println("Hing " + event1.getCode());
                    break;
            }
        });

        main_stuff.setOnKeyReleased(event -> {
            switch(event.getCode()) {
                case CONTROL:
                    System.out.println("hari om");
                    stick_generate.stop();
                    switch(stick_rotate) {
                        case 0:
                            stick_rotation.play();
                            //execution after rotation animation
                            stick_rotation.setOnFinished(e -> {

                                if(this.Stick_checker() == 1){
                                    int s_hero_layoutX_initial = (int) s_hero.getLayoutX();
                                    Timeline move_s_hero_right = new Timeline(new KeyFrame(Duration.seconds(0.007), e1 -> {
                                        //making the guy run
                                        s_hero.setLayoutX(s_hero.getLayoutX() + 1);
                                        //unfinshed bussness to work from here need to do some reaserch working from here
                                        if(cherry_is_there && s_hero.getLayoutX()==(coin.getX())){
                                            System.out.println("Bingoo");
                                        }
                                    }));
                                    move_s_hero_right.setCycleCount((int) (next_platform.getLayoutX() + next_platform.getWidth()) - s_hero_layoutX_initial-45);
                                    move_s_hero_right.play();
                                }
                                else{

                                    Timeline move_s_hero_right = new Timeline(new KeyFrame(Duration.seconds(0.007), e1 -> {
                                        s_hero.setLayoutX(s_hero.getLayoutX() + 1);
                                    }));
                                    move_s_hero_right.setCycleCount((int) stick.getHeight() + 25);
                                    move_s_hero_right.play();
                                    move_s_hero_right.setOnFinished(e2 ->{
                                        RotateTransition invert_s_hero = new RotateTransition();
                                        invert_s_hero.setNode(s_hero);
                                        invert_s_hero.setDuration(Duration.millis(200));
                                        invert_s_hero.setByAngle(180);
                                        invert_s_hero.play();
                                        invert_s_hero.setOnFinished(e3 ->{
                                            TranslateTransition move_s_hero_down= new TranslateTransition();
                                            move_s_hero_down.setNode(s_hero);
                                            move_s_hero_down.setDuration(Duration.millis(1000));
                                            move_s_hero_down.setByY(500);
                                            move_s_hero_down.play();
                                        });
                                    });
                                }

                            });

                            stick_rotate=1;
                            break;
                        case 1:
                            System.out.println("Stick has rotated");
                            break;
                    }
                    character_fate=this.Stick_checker();
                    break;
                case SHIFT:
                    //I have added this as a case of example : agar tujhe aur koi key press add karna ho toh just add a case here
                    //Aur yeh optimised hai: he he :)
                    System.out.println("Hing");
                    break;
            }
        });

    }



    public void pause_game(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("pause_menu.fxml")));
        Game_Stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Game_Scene = new Scene(root);
        Game_Stage.setScene(Game_Scene);
        Game_Stage.show();
    }
    public void game_over(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("game_over.fxml")));
        Game_Stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Game_Scene = new Scene(root);
        Game_Stage.setScene(Game_Scene);
        Game_Stage.show();
    }

     
    // public void move_character(){}
    // public void invert_character(){}
    // public void shift_to_Game_Stage(){}
    // public void collect_cherry(){}
    // public void get_score(){}
    // public void set_score(){}
    // public void get_cherry_count(){}
    // public void set_cherry_count(){}
}