package com.example.stick_hero;
import javafx.animation.*;
import java.util.Random;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;
import java.io.IOException;
import java.util.Objects;

public class GamePlay  {

    private Stage Game_Stage;
    private Scene Game_Scene;
    private int stick_has = 1;
    private int stick_rotate = 0;
    @FXML
    private ImageView s_hero;
    @FXML
    private Rectangle stick;
    @FXML
    private Rectangle starting_platform;
    @FXML
    private Rectangle next_platform;
    @FXML
    AnchorPane main_stuff;
    @FXML
    private TextField coin_field;
    @FXML
    private TextField score_field;
    @FXML
    private Pane game_over_pane;
    public boolean game_over_flag;
    private int saved_score;
    public int score = 0;
    public int coin_count = 0;
    public int character_fate;
    public int invert = 0;
    public boolean cherry_is_there=false;
    public ImageView coin;
    public int Stick_checker(){
        double p = starting_platform.getLayoutX()+starting_platform.getWidth();
        double separation=(next_platform.getLayoutX()-p);
        System.out.println(separation);
        double difference=stick.getHeight()-separation;
        if(difference<0){
            //stick too short case
            System.out.println("OYE PAPAJI! OYE PAPAJI!");
            return -1;
        }

            else if(difference>next_platform.getWidth()){
                //stick too long case
                System.out.println("PAIN MAKES ME NUMB");
                return 0;
            }else{
                //stick just right
                System.out.println("JAI GANESH!");
                return 1;
            }


    }
    public double create_pillar(){
         //random numbers for variable pillar position and width
        Random rand = new Random();
        double rand_dub1 = rand.nextDouble(115,435);
        double max_allowed_width=569-rand_dub1;
        double rand_dub2 = rand.nextDouble(45,max_allowed_width);
        System.out.println("Random Doubles: "+rand_dub1);
        System.out.println("Random Doubles: "+rand_dub2);
        next_platform.setLayoutX(rand_dub1);
        next_platform.setWidth(rand_dub2);
        FadeTransition pillar_ft = new FadeTransition(Duration.seconds(1));
        pillar_ft.setNode(next_platform);
        pillar_ft.setFromValue(0);
        pillar_ft.setToValue(1);
        pillar_ft.play();
        return rand_dub1;
    }
    public double position_of_cherry(double r){
        double a=0;
        Random ra =new Random();
        a=ra.nextDouble(starting_platform.getLayoutX()+starting_platform.getWidth(),r-25);
        return a;
    }
    public int chanceofcherry(){
        int a=0;
        Random raa=new Random();
        a=raa.nextInt(0,3);
        return a;
    }
    public void create_cherry(double a){
        //cherry ka luck wala feature added here
        coin = new ImageView();
        coin.setFitHeight(30);
        coin.setFitWidth(25);
        coin.setImage(new Image(getClass().getResourceAsStream("coin.png")));
        double position_of_next=a;
        int luck=chanceofcherry();
        System.out.println(luck);
        if(luck==0){
            double hello=position_of_cherry(position_of_next);
            main_stuff.getChildren().add(coin);
            coin.setLayoutX(hello);
            coin.setY(215+50);
            cherry_is_there=true;
            System.out.println(hello);
        }
    }
    public void initialize(){
        coin_field.setStyle("-fx-background-color: transparent;");
        score_field.setStyle("-fx-background-color: transparent;");
        //stick generator
        Timeline stick_generate = new Timeline(new KeyFrame(Duration.seconds(0.01), event -> {
            stick.setHeight(stick.getHeight() + 1);
            stick.setY(stick.getY() - 1);
        }));
        stick_generate.setCycleCount(Timeline.INDEFINITE);

        //stick rotation timeline
        Rotate rotation = new Rotate();
        rotation.pivotXProperty().bind(stick.xProperty());
        rotation.pivotYProperty().bind(stick.yProperty().add(stick.heightProperty()));
        stick.getTransforms().add(rotation);
        Timeline stick_rotation = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(rotation.angleProperty(), 0)),
                new KeyFrame(Duration.seconds(0.5), new KeyValue(rotation.angleProperty(), 90))
        );

        double set=create_pillar();
        create_cherry(set);

        //Don't make multiple setOnKeyPressed as the code will call the last event handler
        //this is our keyboard input to code execution block

        main_stuff.setOnKeyPressed( event1 -> {
            switch(event1.getCode()) {
                case CONTROL:
                    System.out.println("hari om "+ event1.getCode());
                    switch(stick_has) {
                        case 0:
                            System.out.println("Stick already made");
                            break;
                        case 1:
                            stick_generate.play();
                            stick_has=0;
                            break;
                    }
                    break;
                case SHIFT:
                    switch(invert){
                        case 0 :
                            invert = 1;
                            System.out.println("Invert value : " + invert);
                            s_hero.setLayoutY(s_hero.getLayoutY() + 50);
                            RotateTransition invert_s_hero = new RotateTransition();
                            invert_s_hero.setAxis(Rotate.X_AXIS);
                            invert_s_hero.setNode(s_hero);
                            invert_s_hero.setDuration(Duration.millis(50));
                            invert_s_hero.setByAngle(180);
                            invert_s_hero.play();
                            break;
                        case 1 :
                            invert = 0;
                            System.out.println("Invert value : " + invert);
                            s_hero.setLayoutY(s_hero.getLayoutY() - 50);
                            RotateTransition re_invert_s_hero = new RotateTransition();
                            re_invert_s_hero.setAxis(Rotate.X_AXIS);
                            re_invert_s_hero.setNode(s_hero);
                            re_invert_s_hero.setDuration(Duration.millis(50));
                            re_invert_s_hero.setByAngle(180);
                            re_invert_s_hero.play();
                            break;
                    }
                    //I have added this as a case of example : agar tujhe aur koi key press add karna ho toh just add a case here
                    //Aur yeh optimised hai: he he :)
                    System.out.println("Hing " + event1.getCode());
                    break;
            }
        });

        main_stuff.setOnKeyReleased(event -> {
            switch(event.getCode()) {
                case CONTROL:
                    System.out.println("hari om");
                    stick_generate.stop();
                    switch(stick_rotate) {
                        case 0:
                            stick_rotation.play();
                            //execution after rotation animation
                            stick_rotation.setOnFinished(e -> {

                                if(this.Stick_checker() == 1){
                                    int s_hero_layoutX_initial = (int) s_hero.getLayoutX();
                                    Timeline move_s_hero_right = new Timeline(new KeyFrame(Duration.seconds(0.007), e1 -> {
                                        s_hero.setLayoutX(s_hero.getLayoutX() + 1);
                                        if(cherry_is_there && (coin.getLayoutX() - s_hero.getLayoutX() < 30) && (coin.getLayoutX() - s_hero.getLayoutX() > 10) && invert == 1){
                                            coin.setOpacity(0);
                                            System.out.println("Bingoo");
                                        }
                                        if(invert == 1 && (next_platform.getLayoutX() - s_hero.getLayoutX() < 25) && (next_platform.getLayoutX() - s_hero.getLayoutX() > 0)){
                                            game_over_flag = true;
                                            Timeline move_s_hero_left = new Timeline(new KeyFrame(Duration.seconds(0.007), e_left ->{
                                                s_hero.setLayoutX(s_hero.getLayoutX()-1);
                                            }));
                                            move_s_hero_left.setCycleCount(10);
                                            move_s_hero_left.play();
                                            TranslateTransition move_s_hero_down= new TranslateTransition();
                                            move_s_hero_down.setNode(s_hero);
                                            move_s_hero_down.setDuration(Duration.millis(1000));
                                            move_s_hero_down.setByY(500);
                                            move_s_hero_down.setOnFinished(e_fin -> {
                                                game_over_pane.setLayoutX(150-55);
                                                game_over_pane.setLayoutY(starting_platform.getLayoutY()-225);
                                            });
                                            move_s_hero_down.play();

                                            //end the game
                                        }
                                    }));
                                    move_s_hero_right.setCycleCount((int) (next_platform.getLayoutX() + next_platform.getWidth()) - s_hero_layoutX_initial-45);
                                    move_s_hero_right.play();
                                    move_s_hero_right.setOnFinished(e_left -> {
                                        if(!game_over_flag){
                                            this.shift_to_left(s_hero_layoutX_initial);
                                            score++;
                                            score_field.setText(String.valueOf(score));
                                        }
                                    });
                                }
                                else{

                                    Timeline move_s_hero_right = new Timeline(new KeyFrame(Duration.seconds(0.007), e1 -> {
                                        s_hero.setLayoutX(s_hero.getLayoutX() + 1);
                                        if(cherry_is_there && (coin.getLayoutX() - s_hero.getLayoutX() < 25) && invert == 1){
                                            coin.setOpacity(0);
                                            System.out.println("Bingoo");
                                        }
                                        System.out.println(s_hero.getX() - coin.getX());
                                        if(invert == 1 && (next_platform.getLayoutX() - s_hero.getLayoutX() < 25) && (next_platform.getLayoutX() - s_hero.getLayoutX() > 0)){
                                            Timeline move_s_hero_left = new Timeline(new KeyFrame(Duration.seconds(0.007), e_left ->{
                                                s_hero.setLayoutX(s_hero.getLayoutX()-1);
                                            }));
                                            move_s_hero_left.setCycleCount(10);
                                            move_s_hero_left.play();
                                            TranslateTransition move_s_hero_down= new TranslateTransition();
                                            move_s_hero_down.setNode(s_hero);
                                            move_s_hero_down.setDuration(Duration.millis(1000));
                                            move_s_hero_down.setByY(500);
                                            move_s_hero_down.setOnFinished(e_fin -> {
                                                game_over_pane.setLayoutX(150-55);
                                                game_over_pane.setLayoutY(starting_platform.getLayoutY()-225);
                                            });
                                            move_s_hero_down.play();
                                            //end the game
                                        }
                                    }));
                                    move_s_hero_right.setCycleCount((int) stick.getHeight() + 25);
                                    move_s_hero_right.play();
                                    move_s_hero_right.setOnFinished(e2 ->{
                                        RotateTransition invert_s_hero = new RotateTransition();
                                        invert_s_hero.setNode(s_hero);
                                        invert_s_hero.setDuration(Duration.millis(200));
                                        invert_s_hero.setByAngle(180);
                                        invert_s_hero.play();
                                        invert_s_hero.setOnFinished(e3 ->{
                                            TranslateTransition move_s_hero_down= new TranslateTransition();
                                            move_s_hero_down.setNode(s_hero);
                                            move_s_hero_down.setDuration(Duration.millis(1000));
                                            move_s_hero_down.setByY(500);
                                            move_s_hero_down.setOnFinished(e_fin -> {
                                                game_over_pane.setLayoutX(150-55);
                                                game_over_pane.setLayoutY(starting_platform.getLayoutY()-225);
                                            });
                                            move_s_hero_down.play();
                                        });
                                    });
                                }

                            });

                            stick_rotate=1;
                            break;
                        case 1:
                            System.out.println("Stick has rotated");
                            break;
                    }
                    character_fate=this.Stick_checker();
                    break;
                case SHIFT:
                    // No need for this portion
                    System.out.println("Hing");
                    break;
            }
        });

    }



    public void pause_game(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("pause_menu.fxml")));
        Game_Stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Game_Scene = new Scene(root);
        Game_Stage.setScene(Game_Scene);
        Game_Stage.show();
    }
    public void game_over(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("game_over.fxml")));
        Game_Stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Game_Scene = new Scene(root);
        Game_Stage.setScene(Game_Scene);
        Game_Stage.show();
    }
    public void quit_game(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("main_menu.fxml")));
        Game_Stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Game_Scene = new Scene(root);
        Game_Stage.setScene(Game_Scene);
        Game_Stage.show();
    }
    public void revive_and_continue(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("game_play.fxml")));
        Game_Stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Game_Scene = new Scene(root);
        Game_Stage.setScene(Game_Scene);
        Game_Stage.show();
    }
    public void restart_game(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("game_play.fxml")));
        Game_Stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Game_Scene = new Scene(root);
        Game_Stage.setScene(Game_Scene);
        Game_Stage.show();
    }
    public void shift_to_left(double initial){
        Timeline move_s_hero_left = new Timeline(new KeyFrame(Duration.seconds(0.003), e1 -> {
            s_hero.setLayoutX(s_hero.getLayoutX() - 1);
        }));
        Timeline move_starting_platform_left = new Timeline(new KeyFrame(Duration.seconds(0.003), e2 -> {
            starting_platform.setLayoutX(starting_platform.getLayoutX() - 1);
        }));
        Timeline move_next_platform_left = new Timeline(new KeyFrame(Duration.seconds(0.003), e3 -> {
            next_platform.setLayoutX(next_platform.getLayoutX() - 1);
        }));
        Timeline move_stick_left = new Timeline(new KeyFrame(Duration.seconds(0.003), e4 -> {
            stick.setLayoutX(stick.getLayoutX() - 1);
        }));
        Timeline move_coin_left = new Timeline(new KeyFrame(Duration.seconds(0.003), e5 -> {
            coin.setLayoutX(stick.getLayoutX() - 1);
        }));
        move_s_hero_left.setCycleCount((int)(s_hero.getLayoutX() - initial));
        move_next_platform_left.setCycleCount((int)(s_hero.getLayoutX() - initial));
        move_starting_platform_left.setCycleCount((int)(s_hero.getLayoutX() - initial));
        move_stick_left.setCycleCount((int)(s_hero.getLayoutX() - initial));
        move_coin_left.setCycleCount((int)(s_hero.getLayoutX() - initial));
        move_s_hero_left.play();
        move_next_platform_left.play();
        move_starting_platform_left.play();
        move_stick_left.play();
        move_coin_left.play();
        main_stuff.getChildren().remove(stick);
    }

}